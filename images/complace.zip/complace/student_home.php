<?php include_once('common/config.php');
include_once('common/header.php');
include_once('common/students_side.php');

?>
<body>


<div class="content">
	<div class="container">
	
					<div class="content-mid">
						<div class="col-md-4 content-top1">
						<div class=" content-top2">
							<h4>Design Thinking</h4>
							<h6> There are many variations</h6>
							<p>We specifically develop our educational programming particularly with our members in mind. Along with extreme pratice session and the recuirters code of conduct.</p>
						</div>
						</div>
						<div class="col-md-4 content-top1">
						<div class=" content-top2">
							<h4> Library </h4>
							<h6> Assets and Variations</h6>
							<p>There are many variations of assets all up to date, we take into practice we maintain the SLA and KPI's without fail, by injected humour.</p>
						</div>
						</div>
						<div class="col-md-4 content-mid-1">
							<div class="port effect-1">
								<div class="image-box">
									<img src="Assets/images/cover2.jpg" alt="" class="img-responsive">
								</div>
								<div class="text-desc text-ed">
									<h6>Seminars</h6>
									<p>Camplce is comprised of a diverse membership and there are a variety of events to meet your needs. </p>	
								</div>
							</div>
						</div>
					<div class="clearfix"></div>
					</div>
			</div>
		</div>
	
	<!---->
	<div class="services">
		<div class="container">
		<div class="service-head">
			<h3>Services</h3>
				<p> The End of all knowledge should be service to others.</p>
				<p> We beleive is the best way to find yourselves is to loose yourselves in service of others</p>
			</div>
			<div class="servies-top">
			<div class="col-md-7 us-ser">
				<div class=" why-choose">
					<div class=" hi-icon-effect-2 hi-icon-effect-2a">
						<a href="#set-6" class="hi-icon  glyphicon glyphicon-book"></a>
					</div>
					<div class="ser-top "> 
						<h5>Our Values</h5>
						<p>Integrity & Accountability.<br/>Respect for each Individual<br/>Sensitivity towards Social Responsibilities<br/>Unfettered Spirit of Learning, Exploration,Rationality & Enterprise</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class=" why-choose">
						<div class=" hi-icon-effect-2 hi-icon-effect-2a">
						<a href="#set-6" class="hi-icon  glyphicon glyphicon-leaf"></a>
					</div>
					<div class="ser-top"> 
						<h5>Our Strategy</h5>					
						<p> To become an Institute of Repute
 <br/>To become the Preferred Recruitment     Destination by the Industry</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class=" why-choose">
						<div class=" hi-icon-effect-2 hi-icon-effect-2a">
						<a href="#set-6" class="hi-icon  glyphicon glyphicon-pencil"></a>
					</div>
					<div class="ser-top"> 
						<h5>Our Mission</h5>
						<p>To provide state-of-the-art infrastructure and right academic ambience for developing professional skills as well as an environment for growth of leadership and managerial skills which leads to fair competancy <br/><br/></p>
					</div>
					<div class="clearfix"> </div>
				</div>
		
			</div>
			<div class="col-md-5 service-mid">
				<img src="Assets/images/rec_place.png" alt="" class="img-responsive"><h3>Our Progress</h3>
			</div>
				<div class="clearfix"> </div>
			</div>
			</div>
		</div>

<div class="test">
		<div class="container">
		
				
			<div class="clearfix"> </div>
			</div>
			
				
			<div class="clearfix"> </div>
			</div>
		</div>
	</div>

</body>
<?php include_once('common/footer.php')?>