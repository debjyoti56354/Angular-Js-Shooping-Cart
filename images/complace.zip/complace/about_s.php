<?php include_once('common/config.php');
include_once('common/header.php');
include_once('common/students_side.php');

?> 
<!-- about -->
<div class="about">
				<div class="container">
				<div class="about-head">
					<h2>About</h2>
					<p> Keeping in view the growing needs of industry and society, we are committed to creating an environment, which will raise the intellectual and moral standards. Our endeavor is to strive for the overall development of students, thereby enabling them to accept challenges.</p>
				</div>
					<div class="about-grids">
					<div class="col-md-5 about-grid1">
						
							<h3 >Overcome Fear's </h3>
							<div class="about-img">
								<img src="Assets/images/aa.jpg" class="img-responsive" alt="">
							</div>
							<h4>By Uplifting and Inspiring</h4>
								<p>One of the best ways to get yourself to learn and grow is by consiously putting yourself into slightly challenging or uncomfortable siuations.This way you are learning to adapt to any situation that comes your way, most importantly,you are building confidance in yourself so that you will be less afraid of change. </p>
							
						</div>
						<div class="col-md-7 about-grid">
							<h3>Why Us</h3>
							<h5>Camplace is an upcoming Online Placement Portal, catering to multifarious job seekers as well as recruiters in India. When it comes to searching jobs, the name Camplace serves as a preferred Jobs. The reputed players of the modern corporate world frequently browse through the portal to hire professionals from different industrial segments. Camplace is a stepping-stone to a rich career opportunity, no matter you are a novice or experienced.</h5>
							<p></p>
							<div class="about-top">
								<div class="col-md-6 about-left">
									<h4>Placement Services</h4>
									<p>Placement is a technique of distributing a particular employment to each of the named applicants. Placement Services includes allocating a particular rank and obligation to a person.</p>
								</div>
								<div class="col-md-6 about-right">
								<h4>Human Resource Services</h4>
									<p>Human Resource refer to the individuals or personnel or workforce within an organisation responsible for performing the tasks given to them for the purpose of achievement of goals and objectives</p>
								</div>
								<div class="clearfix"></div>
							</div>
							
						</div>
						
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
<!---->



<?php 
include_once('common/footer.php');?>