<?php
/*$DOCUMENT_ROOT = $_SERVER ['DOCUMENT_ROOT'];
require_once (plugin_dir_path(__FILE__) . '/common/config.php');
include_once (plugin_dir_path(__FILE__) . '/common/header.php');*/
include_once('common/config.php');
include_once('common/admin_header.php');
include_once('common/admin_side.php');
session_start();
/*$chan = $_SESSION['user_name'];
$sql="SELECT*FROM supplier";
$query_result=mysqli_query ($conn,$sql);*/

?>
<body>
njnsjkdfnjnfjk
</body>

<?php include_once('common/admin_footer.php')?>